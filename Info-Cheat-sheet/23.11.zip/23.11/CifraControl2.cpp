#include <iostream>
using namespace std;

int SumaCifrelor(int n)
{
	if (n == 0) return 0;
	return n % 10 + SumaCifrelor(n / 10);
}

int CifraControl(int n)
{
	if (n <= 9) return n;
	return CifraControl(SumaCifrelor(n));
}

int CifraControlFormula(int n)
{
	if (n == 0) return 0;
	if (n % 9 == 0) return 9;
	return n % 9;
}

int main()
{
	int n;
	cin >> n;
	cout << CifraControl(n) << ' ' << CifraControlFormula(n);
}



