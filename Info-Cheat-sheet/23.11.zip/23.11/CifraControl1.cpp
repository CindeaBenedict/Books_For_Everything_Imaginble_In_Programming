#include <iostream>
using namespace std;

int SumaCifrelor(int n)
{
	int sc = 0;
	while (n)
	{
		sc += n % 10;
		n /= 10;
	}
	return sc;
}

int CifraControl(int n)
{
	while (n > 9)
	{
		n = SumaCifrelor(n);
	}
	
	return n;
}

int main()
{
	int n;
	cin >> n;
	cout << CifraControl(n);
}



