#include <iostream>
using namespace std;

int Cate(int n, int m)
{
	if (n <= m)
	{
		if (n % 2 == 0 && n % 3 != 0)	
			return 1 + Cate(n + 1, m);
		return Cate(n + 1, m);
	}
	
	return 0;
}

int main()
{
	int n;
	
	cout << Cate(1, 215);
}



