/* Cmmmc a doua numere naturale 
 * 
 * 
 * Cmmmc(a, b) = a * b / Cmmdc(a, b)
 */ 
#include <iostream>
using namespace std;
         
int Cmmdc(int a, int b)
{
	if (b == 0) return a;
	return Cmmdc(b, a % b);
}

int Cmmmc(int a, int b)
{
	return a * b / Cmmdc(a, b);
}

int main()
{
	int x, y;
	cin >> x >> y;
	cout << Cmmmc(x,  y);
}





