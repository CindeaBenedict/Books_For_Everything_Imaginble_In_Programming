/* Cmmdc a doua numere naturale 
 * Alg lui Euclid
 * 
 * Metoda imparitilor repetate
 * 
 * Teorema imartirii cu rest
 * 
 * a = b * cat + rest
 * 
 * Cmmdc(a, b) = Cmmdc(b, rest)   daca b  != 0
               = a                daca b = 0 
               
    unde rest = a % b
          
 *  a  b    rest
 * 48  26    22
 * 26  22     4
 * 22  4      2
 *  4  2      0
 *  2  0 
 * =======
 * Cmmdc(48, 26) = 2
 * 
 */ 
#include <iostream>
using namespace std;
         
int Cmmdc(int a, int b)
{
	if (b == 0) return a;
	return Cmmdc(b, a % b);
}

int main()
{
	int x, y;
	cin >> x >> y;
	cout << Cmmdc(x,  y);
}





