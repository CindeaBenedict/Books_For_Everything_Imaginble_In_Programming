/* Numarul divizorilor
 * unui numar natural
 * 
 * Complexitate: O(sqrt(n))
 */ 
#include <iostream>
using namespace std;

int NrDiv(int n)  // O(sqrt(n))
{
	int nd = 0;   // numarul divizorilor lui n
	
	for (int d = 1; d * d <= n; ++d)
		if (n % d == 0)
		{
			nd++;
			if (d * d != n)
				nd++;
		}
		
	return nd;
}

int main()
{
	int n;
	cin >> n;
	cout << NrDiv(n);
}
