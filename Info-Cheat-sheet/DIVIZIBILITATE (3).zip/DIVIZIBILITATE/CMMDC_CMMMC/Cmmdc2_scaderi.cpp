/* Cmmdc a doua numere naturale 
 * Metoda scaderilor repetate
 * O(max(a, b))
 * 
 * Cmmdc(a, b) = Cmmdc(a - b, b)   daca a > b
               = Cmmdc(a, b - a)   daca b > a
               = a                 daca a = b 
 * 
 *  a  b
 * 48  26
 * 22  26
 * 22   4
 * 18   4
 * 14   4
 * 10   4
 *  6   4
 *  2   4
 *  2   2
 * =======
 * Cmmdc(48, 26) = 2
 * 
 */ 
#include <iostream>
using namespace std;

// numare naturale 0, 1, 2, 3, 

// 0 <= a, b <= 1000

//             
int Cmmdc(int a, int b)
{
	if (b == 0) return a;  // daca a sau b pot fi 0
	if (a == 0) return b;
	
	while (a != b)
		if (a > b)
		    a -= b;
		else
			b -= a;
			
	return a;
}


int main()
{
	
}





