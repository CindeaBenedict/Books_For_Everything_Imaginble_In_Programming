/* Cmmmc a n numere naturale
 * 
 * Cmmmc(a, b, c) = Cmmmc(Cmmdc(a, b), c)
 * 
 */ 
#include <fstream>
using namespace std;
         
const int N = 1000;         

void CitesteSir(int a[], int& n);
int Cmmdc2(int a, int b);
int Cmmmc2(int a, int b);
int CmmmcN(int a[], int n);


int main()
{
	int a[N], n;
	CitesteSir(a, n);
	
	ofstream fout("cmmmcn.out");
	fout << CmmmcN(a, n);
}

int CmmmcN(int a[], int n)
{
	if (n == 0) return 1;
	return Cmmmc2(a[n], CmmmcN(a, n - 1));
}

int Cmmmc2(int a, int b)
{
	return a * b / Cmmdc2(a, b);
}

int Cmmdc2(int a, int b)
{
	if (b == 0) return a;
	return Cmmdc2(b, a % b);
}

void CitesteSir(int a[], int& n)
{
	ifstream fin("cmmmcn.in");
	fin >> n;
	for (int i = 1; i <= n; ++i)
		fin >> a[i];
}

