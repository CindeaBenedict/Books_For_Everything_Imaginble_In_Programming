/* Cmmdc a n numere naturale
 * 
 * Cmmdc(a, b, c) = Cmmdc(Cmmdc(a, b), c)
 * 
 */ 
#include <fstream>
using namespace std;
         
const int N = 1000;         

void CitesteSir(int a[], int& n);
int Cmmdc2(int a, int b);
int CmmdcN(int a[], int n);


int main()
{
	int a[N], n;
	CitesteSir(a, n);
	
	ofstream fout("cmmdcn.out");
	fout << CmmdcN(a, n);
}

int CmmdcN(int a[], int n)
{
	if (n == 0) return 0;
	return Cmmdc2(a[n], CmmdcN(a, n - 1));
}

int Cmmdc2(int a, int b)
{
	if (b == 0) return a;
	return Cmmdc2(b, a % b);
}

void CitesteSir(int a[], int& n)
{
	ifstream fin("cmmdcn.in");
	fin >> n;
	for (int i = 1; i <= n; ++i)
		fin >> a[i];
}

