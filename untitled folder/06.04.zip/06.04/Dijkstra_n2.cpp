/* Algoritmul lui Dijkstra
 * Complexitate: O(n^2)
 */ 
#include <fstream>
using namespace std;

ifstream fin("dijkstra.in");
ofstream fout("dijkstra.out");

const int N = 101, INF = 1e6;
int c[N][N];   // matricea ponderilor (costurile arcelor)
int n, p;
int d[N];      // d[i] = distanta minima d ela nodul sursa (p) la nodul i
bool s[N];     // retine starea de selectare a nodurilor

void CitesteGraf();
void Dijkstra(int x);
void ScrieDistMinime();

int main()
{
	CitesteGraf();
	Dijkstra(p);
	ScrieDistMinime();
}

void Dijkstra(int x)
{
	s[x] = true;
	// initializam sirul d[] cu costurile arcelor dintre p si restul nodurilor
	for (int i = 1; i <= n; ++i)
		d[i] = c[x][i];
	
	for (int pas = 1; pas <= n - 1; pas++)
	{
		// cautam nodul (x) neselectat inca,
		//  aflat la dist cea mai mica de sursa (p)
		int dmin = INF;
		for (int i = 1; i <= n; ++i)
			if (!s[i] && d[i] < dmin)
			{
				dmin = d[i];
				x = i;
			}
		if (dmin != INF)
		{
			s[x] = true;
			for (int y = 1; y <= n; ++y)
				if (d[y] > d[x] + c[x][y])
					d[y] = d[x] + c[x][y];
		}
	}
}

void ScrieDistMinime()
{
	for (int i = 1; i <= n; ++i)
		if (d[i] != INF)
			fout << d[i] << ' ';
		else
			fout << "-1 ";
}

void CitesteGraf()
{
	fin >> n >> p;
	
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			if (i != j)
				c[i][j] = INF;
	
	int x, y, cost;
	
	while (fin >> x >> y >> cost)
		c[x][y] = cost;
}

